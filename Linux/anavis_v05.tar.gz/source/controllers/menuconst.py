class MenuControllerConst():
    _STATISTICS = '-Statistics'
    _OVERVIEW = '-Overview'
    _HEATMAP = '-Heatmap'
    _LINREG = '-LinReg'
    _BOXPLOTS = '-Boxplots'
    _BOXPLOT = '-Boxplot'
    _SCATTER = '-Scatter'
    _BARPLOT = '-Barplot'
