"""
Enthält die Datenstruktur des Programms.

DataContainer: Wrapper eins pandas.DataFrame
"""