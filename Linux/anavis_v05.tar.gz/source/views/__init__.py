"""
Enthält die verschiedenen Klassen für die Views.

- DataView: für tabellarische Darstellung
- PlotView: für Grafik inklusive Grafik-Toolbar
"""