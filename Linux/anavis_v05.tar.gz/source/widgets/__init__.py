"""
Enthält zusätzliche grafische Elemente des Programms.

Dialogs

- LinRegInputDialog
- NormalizeDialog

Widets

- MyNavigationToolbar2Tk
- ScrollableNotebook
- Statusbar
- TreeViewToolTip
"""